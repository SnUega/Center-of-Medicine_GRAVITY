/**
 * FloatingLines — vanilla Three.js port (no React).
 * Full-viewport animated line background for "Site under development" stub.
 */
(function () {
  'use strict';

  const vertexShader = `
precision highp float;
void main() {
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

  const fragmentShader = `
precision highp float;

uniform float iTime;
uniform vec3  iResolution;
uniform float animationSpeed;

uniform bool enableTop;
uniform bool enableMiddle;
uniform bool enableBottom;

uniform int topLineCount;
uniform int middleLineCount;
uniform int bottomLineCount;

uniform float topLineDistance;
uniform float middleLineDistance;
uniform float bottomLineDistance;

uniform vec3 topWavePosition;
uniform vec3 middleWavePosition;
uniform vec3 bottomWavePosition;

uniform vec2 iMouse;
uniform bool interactive;
uniform float bendRadius;
uniform float bendStrength;
uniform float bendInfluence;

uniform bool parallax;
uniform float parallaxStrength;
uniform vec2 parallaxOffset;

uniform vec3 lineGradient[8];
uniform int lineGradientCount;
uniform float lineGlow;

const vec3 BLACK = vec3(0.0);
const vec3 PINK  = vec3(233.0, 71.0, 245.0) / 255.0;
const vec3 LIGHT_GRAY = vec3(0.88);

mat2 rotate(float r) {
  return mat2(cos(r), sin(r), -sin(r), cos(r));
}

vec3 background_color(vec2 uv) {
  vec3 col = vec3(0.0);
  float y = sin(uv.x - 0.2) * 0.3 - 0.1;
  float m = uv.y - y;
  col += mix(LIGHT_GRAY, BLACK, smoothstep(0.0, 1.0, abs(m)));
  float diag = (uv.x - uv.y) * 0.35 + 0.5;
  diag = clamp(diag, 0.0, 1.0);
  float pinkFade = smoothstep(0.0, 1.0, abs(m - 0.8) * (1.0 - diag * 0.55));
  col += mix(PINK, BLACK, pinkFade);
  return col * 0.5;
}

vec3 getLineColor(float t, vec3 baseColor) {
  if (lineGradientCount <= 0) return baseColor;
  vec3 gradientColor;
  if (lineGradientCount == 1) {
    gradientColor = lineGradient[0];
  } else {
    float clampedT = clamp(t, 0.0, 0.9999);
    float scaled = clampedT * float(lineGradientCount - 1);
    int idx = int(floor(scaled));
    float f = fract(scaled);
    int idx2 = min(idx + 1, lineGradientCount - 1);
    vec3 c1 = lineGradient[idx];
    vec3 c2 = lineGradient[idx2];
    gradientColor = mix(c1, c2, f);
  }
  return gradientColor * 0.5 + vec3(lineGlow);
}

float wave(vec2 uv, float offset, vec2 screenUv, vec2 mouseUv, bool shouldBend) {
  float time = iTime * animationSpeed;
  float x_offset   = offset;
  float x_movement = time * 0.1;
  float amp        = sin(offset + time * 0.2) * 0.3;
  float y          = sin(uv.x + x_offset + x_movement) * amp;

  if (shouldBend) {
    vec2 d = screenUv - mouseUv;
    float influence = exp(-dot(d, d) * bendRadius);
    float bendOffset = (mouseUv.y - screenUv.y) * influence * bendStrength * bendInfluence;
    y += bendOffset;
  }

  float m = uv.y - y;
  return 0.0175 / max(abs(m) + 0.01, 1e-3) + 0.01;
}

void mainImage(out vec4 fragColor, in vec2 fragCoord) {
  vec2 baseUv = (2.0 * fragCoord - iResolution.xy) / iResolution.y;
  baseUv.y *= -1.0;
  if (parallax) baseUv += parallaxOffset;

  vec3 col = background_color(baseUv);
  vec3 b = vec3(0.0);
  vec2 mouseUv = vec2(0.0);
  if (interactive) {
    mouseUv = (2.0 * iMouse - iResolution.xy) / iResolution.y;
    mouseUv.y *= -1.0;
  }

  if (enableBottom) {
    for (int i = 0; i < 24; ++i) {
      if (i >= bottomLineCount) break;
      float fi = float(i);
      float t = fi / max(float(bottomLineCount - 1), 1.0);
      vec3 lineCol = getLineColor(t, b);
      float angle = bottomWavePosition.z * log(length(baseUv) + 1.0);
      vec2 ruv = baseUv * rotate(angle);
      col += lineCol * wave(
        ruv + vec2(bottomLineDistance * fi + bottomWavePosition.x, bottomWavePosition.y),
        1.5 + 0.2 * fi, baseUv, mouseUv, interactive
      ) * 0.2;
    }
  }

  if (enableMiddle) {
    for (int i = 0; i < 24; ++i) {
      if (i >= middleLineCount) break;
      float fi = float(i);
      float t = fi / max(float(middleLineCount - 1), 1.0);
      vec3 lineCol = getLineColor(t, b);
      float angle = middleWavePosition.z * log(length(baseUv) + 1.0);
      vec2 ruv = baseUv * rotate(angle);
      col += lineCol * wave(
        ruv + vec2(middleLineDistance * fi + middleWavePosition.x, middleWavePosition.y),
        2.0 + 0.15 * fi, baseUv, mouseUv, interactive
      ) * 0.45;
    }
  }

  if (enableTop) {
    for (int i = 0; i < 24; ++i) {
      if (i >= topLineCount) break;
      float fi = float(i);
      float t = fi / max(float(topLineCount - 1), 1.0);
      vec3 lineCol = getLineColor(t, b);
      float angle = topWavePosition.z * log(length(baseUv) + 1.0);
      vec2 ruv = baseUv * rotate(angle);
      ruv.x *= -1.0;
      col += lineCol * wave(
        ruv + vec2(topLineDistance * fi + topWavePosition.x, topWavePosition.y),
        1.0 + 0.2 * fi, baseUv, mouseUv, interactive
      ) * 0.1;
    }
  }

  fragColor = vec4(col, 1.0);
}

void main() {
  vec4 color = vec4(0.0);
  mainImage(color, gl_FragCoord.xy);
  gl_FragColor = color;
}
`;

  function hexToVec3(hex) {
    let value = String(hex).trim();
    if (value.startsWith('#')) value = value.slice(1);
    let r = 255, g = 255, b = 255;
    if (value.length === 3) {
      r = parseInt(value[0] + value[0], 16);
      g = parseInt(value[1] + value[1], 16);
      b = parseInt(value[2] + value[2], 16);
    } else if (value.length === 6) {
      r = parseInt(value.slice(0, 2), 16);
      g = parseInt(value.slice(2, 4), 16);
      b = parseInt(value.slice(4, 6), 16);
    }
    return new THREE.Vector3(r / 255, g / 255, b / 255);
  }

  window.initFloatingLines = function (container, options) {
    options = options || {};
    var enabledWaves = options.enabledWaves || ['top', 'middle', 'bottom'];
    var lineCount = typeof options.lineCount === 'number' ? options.lineCount : 7;
    var lineDistance = (typeof options.lineDistance === 'number' ? options.lineDistance : 80) * 0.01;
    var bendRadius = options.bendRadius != null ? options.bendRadius : 20.5;
    var bendStrength = options.bendStrength != null ? options.bendStrength : 0;
    var interactive = options.interactive !== false;
    var parallax = options.parallax !== false;
    var animationSpeed = options.animationSpeed != null ? options.animationSpeed : 1;
    var parallaxStrength = options.parallaxStrength != null ? options.parallaxStrength : 0.2;
    var mouseDamping = options.mouseDamping != null ? options.mouseDamping : 0.05;
    var linesGradient = options.linesGradient || ['#8D5A97', '#a06daa', '#d4b8da'];
    var lineGlow = options.lineGlow != null ? options.lineGlow : 0.08;

    var topWavePosition = options.topWavePosition || { x: 10.0, y: 0.5, rotate: -0.4 };
    var middleWavePosition = options.middleWavePosition || { x: 5.0, y: 0.0, rotate: 0.2 };
    var bottomWavePosition = options.bottomWavePosition || { x: 2.0, y: -0.7, rotate: 0.4 };

    var enableTop = enabledWaves.indexOf('top') !== -1;
    var enableMiddle = enabledWaves.indexOf('middle') !== -1;
    var enableBottom = enabledWaves.indexOf('bottom') !== -1;

    var scene = new THREE.Scene();
    var camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    camera.position.z = 1;

    var renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    container.appendChild(renderer.domElement);

    var lineGradientValue = [];
    for (var i = 0; i < 8; i++) lineGradientValue.push(new THREE.Vector3(1, 1, 1));
    var lineGradientCount = 0;
    if (linesGradient && linesGradient.length > 0) {
      lineGradientCount = Math.min(linesGradient.length, 8);
      for (var g = 0; g < lineGradientCount; g++) {
        var c = hexToVec3(linesGradient[g]);
        lineGradientValue[g].set(c.x, c.y, c.z);
      }
    }

    var uniforms = {
      iTime: { value: 0 },
      iResolution: { value: new THREE.Vector3(1, 1, 1) },
      animationSpeed: { value: animationSpeed },
      enableTop: { value: enableTop },
      enableMiddle: { value: enableMiddle },
      enableBottom: { value: enableBottom },
      topLineCount: { value: lineCount },
      middleLineCount: { value: lineCount },
      bottomLineCount: { value: lineCount },
      topLineDistance: { value: lineDistance },
      middleLineDistance: { value: lineDistance },
      bottomLineDistance: { value: lineDistance },
      topWavePosition: { value: new THREE.Vector3(topWavePosition.x, topWavePosition.y, topWavePosition.rotate) },
      middleWavePosition: { value: new THREE.Vector3(middleWavePosition.x, middleWavePosition.y, middleWavePosition.rotate) },
      bottomWavePosition: { value: new THREE.Vector3(bottomWavePosition.x, bottomWavePosition.y, bottomWavePosition.rotate) },
      iMouse: { value: new THREE.Vector2(-1000, -1000) },
      interactive: { value: interactive },
      bendRadius: { value: bendRadius },
      bendStrength: { value: bendStrength },
      bendInfluence: { value: 0 },
      parallax: { value: parallax },
      parallaxStrength: { value: parallaxStrength },
      parallaxOffset: { value: new THREE.Vector2(0, 0) },
      lineGradient: { value: lineGradientValue },
      lineGradientCount: { value: lineGradientCount },
      lineGlow: { value: lineGlow }
    };

    var material = new THREE.ShaderMaterial({
      uniforms: uniforms,
      vertexShader: vertexShader,
      fragmentShader: fragmentShader
    });
    var geometry = new THREE.PlaneGeometry(2, 2);
    var mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    var clock = new THREE.Clock();
    var targetMouse = new THREE.Vector2(-1000, -1000);
    var currentMouse = new THREE.Vector2(-1000, -1000);
    var targetInfluence = 0;
    var currentInfluence = 0;
    var targetParallax = new THREE.Vector2(0, 0);
    var currentParallax = new THREE.Vector2(0, 0);

    function setSize() {
      var width = container.clientWidth || 1;
      var height = container.clientHeight || 1;
      renderer.setSize(width, height, false);
      uniforms.iResolution.value.set(renderer.domElement.width, renderer.domElement.height, 1);
    }
    setSize();
    var ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(setSize) : null;
    if (ro) ro.observe(container);

    function onPointerMove(ev) {
      var rect = renderer.domElement.getBoundingClientRect();
      var x = ev.clientX - rect.left;
      var y = ev.clientY - rect.top;
      var dpr = renderer.getPixelRatio();
      targetMouse.set(x * dpr, (rect.height - y) * dpr);
      targetInfluence = 1.0;
      if (parallax) {
        var cx = rect.width / 2, cy = rect.height / 2;
        targetParallax.set((x - cx) / rect.width * parallaxStrength, -(y - cy) / rect.height * parallaxStrength);
      }
    }
    function onPointerLeave() {
      targetInfluence = 0;
    }
    if (interactive) {
      renderer.domElement.addEventListener('pointermove', onPointerMove);
      renderer.domElement.addEventListener('pointerleave', onPointerLeave);
    }

    var raf;
    function render() {
      uniforms.iTime.value = clock.getElapsedTime();
      if (interactive) {
        currentMouse.lerp(targetMouse, mouseDamping);
        uniforms.iMouse.value.copy(currentMouse);
        currentInfluence += (targetInfluence - currentInfluence) * mouseDamping;
        uniforms.bendInfluence.value = currentInfluence;
      }
      if (parallax) {
        currentParallax.lerp(targetParallax, mouseDamping);
        uniforms.parallaxOffset.value.copy(currentParallax);
      }
      renderer.render(scene, camera);
      raf = requestAnimationFrame(render);
    }
    render();

    return function dispose() {
      cancelAnimationFrame(raf);
      if (ro) ro.disconnect();
      if (interactive) {
        renderer.domElement.removeEventListener('pointermove', onPointerMove);
        renderer.domElement.removeEventListener('pointerleave', onPointerLeave);
      }
      geometry.dispose();
      material.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
    };
  };
})();
